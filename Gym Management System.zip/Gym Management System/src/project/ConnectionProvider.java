/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.sql.*;
/**
 * @author asus
 */
public class ConnectionProvider {
    public static Connection getCon(){
        //initComponents;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gms","root","");
            //cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/gms [root on Default schema]","root","");
            //st=cn.createStatement();
            //JOptionPane.showMessageDialog(null,"Connected");
            return con;
        }
        catch(Exception e){
            return null;
             //JOptionPane.showMessageDialog(null,"Not Connected");
        }
    }
}
